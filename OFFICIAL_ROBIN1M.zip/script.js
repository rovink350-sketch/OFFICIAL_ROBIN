const KEY='official_robin1m_data';
const ADMIN_PASSWORD='0000'; // CHANGE THIS before publishing
const defaultData={packages:[
{id:1,name:'Starter Package',price:99,description:'Basic package'},
{id:2,name:'Premium Package',price:199,description:'Premium package'},
{id:3,name:'Pro Package',price:499,description:'Advanced package'}],orders:[]};
let data=JSON.parse(localStorage.getItem(KEY)||'null')||defaultData;
let selectedPackage=null;
function save(){localStorage.setItem(KEY,JSON.stringify(data))}
function render(){
document.getElementById('year').textContent=new Date().getFullYear();
document.getElementById('packageGrid').innerHTML=data.packages.map(p=>`<div class="card"><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p><div class="price">₹${Number(p.price).toFixed(0)}</div><button class="btn" onclick="startOrder(${p.id})">Order Now</button></div>`).join('');
document.getElementById('orderList').innerHTML=data.orders.length?data.orders.map(o=>`<div class="order"><div><b>${esc(o.packageName)}</b><br><small>ID: ${esc(o.customerId)}</small><br><small>${o.created}</small></div><span class="status">${esc(o.status)}</span></div>`).join(''):'<div class="card">No orders yet.</div>';
}
function startOrder(id){selectedPackage=data.packages.find(x=>x.id===id);document.getElementById('modalTitle').textContent='Order: '+selectedPackage.name;document.getElementById('modal').classList.remove('hidden')}
function closeModal(){document.getElementById('modal').classList.add('hidden')}
function submitOrder(){
const customerId=document.getElementById('customerId').value.trim(), paymentRef=document.getElementById('paymentRef').value.trim();
if(!customerId||!paymentRef)return alert('Please enter ID and payment reference.');
data.orders.unshift({id:Date.now(),packageName:selectedPackage.name,customerId,paymentRef,status:'Pending verification',created:new Date().toLocaleString()});
save();closeModal();document.getElementById('customerId').value='';document.getElementById('paymentRef').value='';render();alert('Order submitted. Payment must be verified by the administrator.');
}
function openAdmin(){document.getElementById('admin').classList.remove('hidden')}
function closeAdmin(){document.getElementById('admin').classList.add('hidden')}
function loginAdmin(){if(document.getElementById('adminPass').value!==ADMIN_PASSWORD)return alert('Wrong password');document.getElementById('adminPanel').classList.remove('hidden');renderAdmin()}
function renderAdmin(){
document.getElementById('adminPackages').innerHTML=data.packages.map(p=>`<div class="card" style="margin:8px 0"><b>${esc(p.name)}</b> — ₹${p.price}<br><small>${esc(p.description)}</small><br><button class="btn secondary" onclick="editPackage(${p.id})">Edit</button> <button class="btn" onclick="deletePackage(${p.id})">Delete</button></div>`).join('');
document.getElementById('adminOrders').innerHTML=data.orders.length?data.orders.map(o=>`<div class="card" style="margin:8px 0"><b>${esc(o.packageName)}</b> — ${esc(o.customerId)}<br>Ref: ${esc(o.paymentRef)}<br>Status: <b>${esc(o.status)}</b><br><button class="btn" onclick="setStatus(${o.id},'Processing')">Processing</button> <button class="btn" onclick="setStatus(${o.id},'Completed')">Completed</button> <button class="btn secondary" onclick="setStatus(${o.id},'Rejected')">Rejected</button></div>`).join(''):'No orders.'}
function editPackage(id){let p=data.packages.find(x=>x.id===id);let n=prompt('Package name',p.name);if(n===null)return;let price=prompt('Price',p.price);if(price===null)return;let d=prompt('Description',p.description);if(d===null)return;p.name=n;p.price=Number(price)||0;p.description=d;save();render();renderAdmin()}
function addPackage(){let n=prompt('Package name');if(!n)return;let price=prompt('Price','99');let d=prompt('Description','Custom package');data.packages.push({id:Date.now(),name:n,price:Number(price)||0,description:d||''});save();render();renderAdmin()}
function deletePackage(id){if(!confirm('Delete this package?'))return;data.packages=data.packages.filter(x=>x.id!==id);save();render();renderAdmin()}
function setStatus(id,status){let o=data.orders.find(x=>x.id===id);if(o){o.status=status;save();render();renderAdmin()}}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
render();